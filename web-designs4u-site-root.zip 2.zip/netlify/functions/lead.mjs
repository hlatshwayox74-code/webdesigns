/* =====================================================================
   LEAD FUNCTION  |  POST /api/lead
   ---------------------------------------------------------------------
   Emails every enquiry to Web Designs4U, then fans it out to any
   webhooks. Secrets live only in Netlify environment variables.

   Required for email:
   RESEND_API_KEY      From resend.com (free). Sign up with
                       webdesigns4u.co.za@gmail.com and leave LEAD_FROM
                       empty: Resend's test sender can deliver to the
                       account owner's own inbox with no domain setup.
   Optional:
   LEAD_NOTIFY_TO      Default: webdesigns4u.co.za@gmail.com
   LEAD_FROM           Default: "Web Designs4U <onboarding@resend.dev>".
                       Set to an address on your own verified domain later.
   LEAD_CONFIRM        "true" also emails the customer (needs your own
                       verified domain in LEAD_FROM).
   LEAD_WEBHOOK_URLS   Comma-separated: Zapier, Make, n8n, Google Sheets,
                       Airtable, HubSpot, GoHighLevel.

   Response: { ok, emailed } so the website never claims an enquiry
   was delivered when it wasn't.
   ===================================================================== */

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const env = (k) => (process.env[k] || "").trim();
const NOTIFY_TO = () => env("LEAD_NOTIFY_TO") || "webdesigns4u.co.za@gmail.com";
const FROM = () => env("LEAD_FROM") || "Web Designs4U <onboarding@resend.dev>";
const list = (v) => [].concat(v || []).filter(Boolean).join(", ");

// 071 437 9593 -> 27714379593 so you can tap through to the customer's WhatsApp
function waNumber(raw) {
  let d = String(raw || "").replace(/[^\d+]/g, "");
  if (d.startsWith("+")) d = d.slice(1);
  else if (d.startsWith("0") && d.length === 10) d = "27" + d.slice(1);
  return /^\d{9,15}$/.test(d) ? d : "";
}

function saTime(iso) {
  try { return new Intl.DateTimeFormat("en-ZA", { dateStyle: "full", timeStyle: "short", timeZone: "Africa/Johannesburg" }).format(new Date(iso)); }
  catch { return iso; }
}

function fields(lead) {
  const src = lead.source || {};
  const campaign = [src.utm_source, src.utm_medium, src.utm_campaign].filter(Boolean).join(" / ");
  if (lead.kind === "contact") {
    return [
      ["Name", lead.fullName], ["Business", lead.businessName], ["Reply to", lead.reply], ["Message", lead.message],
      ["Source", "Web Designs4U Website (contact panel)" + (campaign ? ` | ${campaign}` : "")],
      ["Date/Time", saTime(lead.received_at)]
    ];
  }
  const p = lead.personalised || {};
  return [
    ["Name", lead.name], ["Business", lead.businessName], ["Business Type", lead.businessType],
    ["What they do", lead.businessDescription], ["Email", lead.email], ["Phone / WhatsApp", lead.phone],
    ["Website Goal", list(lead.goals)], ["Looking for", lead.websiteType], ["Website Style", lead.style],
    ["Existing Website", lead.existingWebsite], ["Message", lead.message],
    ["Journey answers", [p.category, list(p.goals), p.style].filter(Boolean).join(" | ")],
    ["Source", "Web Designs4U Website" + (campaign ? ` | ${campaign}` : src.referrer ? ` | via ${src.referrer}` : "")],
    ["Date/Time", saTime(lead.received_at)]
  ];
}

function emailText(lead) {
  return "WEB DESIGNS4U | NEW WEBSITE ENQUIRY\n\n" +
    fields(lead).map(([k, v]) => `${k}:\n${v || "-"}`).join("\n\n");
}

function emailHtml(lead) {
  const wa = waNumber(lead.phone);
  const rows = fields(lead).map(([k, v]) =>
    `<tr><td style="padding:10px 12px;color:#777;border-bottom:1px solid #eee;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="padding:10px 12px;border-bottom:1px solid #eee;white-space:pre-wrap"><strong>${esc(v || "-")}</strong></td></tr>`).join("");
  const actions = [
    wa ? `<a href="https://wa.me/${wa}" style="display:inline-block;background:#25D366;color:#000;padding:10px 16px;text-decoration:none;font-weight:bold;margin-right:8px">WhatsApp ${esc(lead.name || "them")}</a>` : "",
    lead.email ? `<a href="mailto:${esc(lead.email)}" style="display:inline-block;background:#111;color:#fff;padding:10px 16px;text-decoration:none;font-weight:bold">Reply by email</a>` : ""
  ].join("");
  return `<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;max-width:640px">
    <h2 style="margin:0 0 4px;letter-spacing:.02em">WEB DESIGNS4U | NEW WEBSITE ENQUIRY</h2>
    <p style="margin:0 0 16px;color:#777">${esc(lead.businessName || lead.fullName || "New lead")}</p>
    <table cellpadding="0" cellspacing="0" style="border-collapse:collapse;width:100%">${rows}</table>
    <p style="margin:20px 0 0">${actions}</p></div>`;
}

async function sendEmail({ to, subject, html, text, replyTo }) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${env("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM(), to: [to], subject, html, text, ...(replyTo ? { reply_to: replyTo } : {}) })
  });
  if (!res.ok) throw new Error(`Resend ${res.status}: ${await res.text()}`);
}

async function postWebhook(url, lead) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(lead) });
  if (!res.ok) throw new Error(`Webhook ${url} ${res.status}`);
}

export default async (req, context) => {
  if (req.method !== "POST") return json({ ok: false, error: "Use POST." }, 405);
  const raw = await req.text();
  if (raw.length > 20000) return json({ ok: false, error: "Request too large." }, 413);
  let lead;
  try { lead = JSON.parse(raw); } catch { return json({ ok: false, error: "Body must be JSON." }, 400); }
  if (lead["bot-field"]) return json({ ok: true, emailed: true }); // honeypot: bots see success, nothing is sent
  delete lead["bot-field"];
  const reachable = lead.email || lead.phone || lead.reply;
  if (!reachable) return json({ ok: false, emailed: false, error: "A way to reply is required." }, 422);

  lead.received_at = new Date().toISOString();
  lead.country = context?.geo?.country?.code || "";

  // 1. Email to Web Designs4U: the delivery that decides success.
  let emailed = false, emailError = "";
  if (env("RESEND_API_KEY")) {
    try {
      await sendEmail({
        to: NOTIFY_TO(),
        subject: lead.kind === "contact"
          ? `WEB DESIGNS4U | New message from ${lead.fullName || "the website"}`
          : `WEB DESIGNS4U | New website enquiry: ${lead.businessName || lead.name || "new business"}`,
        html: emailHtml(lead), text: emailText(lead),
        replyTo: lead.email || undefined
      });
      emailed = true;
    } catch (e) { emailError = e.message; console.error("[lead] email failed:", e.message); }
  } else {
    emailError = "RESEND_API_KEY not set";
  }

  // 2. Extras: webhooks and optional customer confirmation. Failures here never block the lead.
  const extras = [];
  env("LEAD_WEBHOOK_URLS").split(",").map((u) => u.trim()).filter(Boolean).forEach((url) => extras.push(postWebhook(url, lead)));
  if (emailed && env("LEAD_CONFIRM") === "true" && lead.email && lead.kind !== "contact") {
    extras.push(sendEmail({
      to: lead.email,
      subject: `${lead.businessName || "Your business"}: your next chapter starts here`,
      html: `<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;max-width:520px"><p>Hi ${esc(lead.name || "there")},</p><p>We've received your enquiry for <strong>${esc(lead.businessName || "your business")}</strong> and we'll be in touch shortly.</p><p>Prefer to chat now? <a href="https://wa.me/27714379593">WhatsApp us on 071 437 9593</a>.</p><p><strong>Web Designs4U</strong><br>Don't just get a website. Get a digital experience.</p></div>`
    }));
  }
  const results = await Promise.allSettled(extras);
  results.filter((r) => r.status === "rejected").forEach((r) => console.error("[lead]", r.reason?.message || r.reason));

  return json({ ok: true, emailed, ...(emailed ? {} : { emailError }) });
};

export const config = { path: "/api/lead" };
